// import logo from './logo.svg';
// import './App.css';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Navbar from './Navbar/navbar';
import BookDetails from './Components/BookDetails';
import Bookform from './Components/Bookform';
import BookList from './Components/BookList';
import BookSearch from './Components/BookSearch';
import Mybooks from './Components/Mybooks';
import Footer from './Components/Footer';
function App() {
  return (
    <div className="App">
      <header className="App-header">
      </header>
      <Router>
      <Navbar />
      <Routes>
          <Route path="/" element={<BookList />} />
          <Route path="/search" element={<BookSearch />}/>
          <Route path="/add" element={<Bookform />} />
          <Route path="/book/:id" element={<BookDetails />} />
          <Route path="/mybooks" element={<Mybooks />} /> 
        </Routes>
        <Footer />
      </Router> 
  </div>
  );
}

export default App;
