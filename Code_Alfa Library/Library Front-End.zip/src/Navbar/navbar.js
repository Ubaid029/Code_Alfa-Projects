
import React from 'react';
import './navbar.css';
import { Link } from 'react-router-dom';
const Logo = require('../Images/Book-logo.png');

export default function Navbar() {
  return (
    <div className="navbody">
      <div className="navbar">
        <div className="nav-logo">
          <img
             className="img-logo"
             src={Logo}
            alt=""
          />
          <p>Book Library</p>
        </div>
        <nav>
          <ul className="nav-menu">
            <li>
              <Link
                to="/"
                className="nav-menu"
                style={{ textDecoration: 'none' }}
              >
                Home
              </Link>
            </li>
            <li>
              <Link
                to="/search"
                className="nav-menu"
                style={{ textDecoration: 'none' }}
              >
                Search
              </Link>
            </li>
            <li>
              <Link
                to="/mybooks"
                className="nav-menu"
                style={{ textDecoration: 'none' }}
              >
                My Books
              </Link>
            </li>
            <li>
              <Link
                to="/add"
                className="nav-menu"
                style={{ textDecoration: 'none' }}
              >
                Request
              </Link>
           </li>
           <li>
          </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}
