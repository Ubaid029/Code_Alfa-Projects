const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
    title: { type: String, 
         },
    author: { type: String,  },
    categories: [{ type: String,  }],
    cover : { type: String,  },
    isbn: { type: String,  },
    mybook: { type:Number},
    borrowingHistory: [
        {
            borrowedDate: Date,
            returnedDate: Date,
        },
    ],
});

module.exports = mongoose.model('Book', BookSchema);


/*

{
    "title": "The Great Gatsby",
    "author": "F. Scott Fitzgerald",
    "categories": ["Fiction", "Classic"],
    "cover": "https://m.media-amazon.com/images/I/81QuEGw8VPL._AC_UF1000,1000_QL80_.jpg",
    "isbn": "9780743273565",
    "borrowingHistory": []
}

{
    "title": "The Catcher in the Rye",
    "author": "J.D. Salinger",
    "categories": ["Fiction", "Classic"],
    "cover":"https://s.yimg.com/zb/imgv1/e9566934-9b79-3cfb-91d5-54223c6b0acf/t_500x300"
    "isbn": "9780316769488",
    "borrowingHistory": []
}

{
    "title": "To Kill a Mockingbird",
    "author": "Harper Lee",
    "categories": ["Fiction", "Classic"],
    "cover": "https://www.arts.gov/sites/default/files/To%20Kill%20a%20Mockingbird.jpg"
    "isbn": "9780060935467",
    "borrowingHistory": []
}

{
    "title": "The Lord of the Rings",
    "author": "J.R.R. Tolkien",
    "categories": ["Fiction", "Fantasy"],
    "cover": "https://cdn11.bigcommerce.com/s-gibnfyxosi/images/stencil/1920w/products/154740/156431/51eq24cRtRL__98083.1615576774.jpg?c=1"
    "isbn": "9780618640157",
    "borrowingHistory": []
}

{
    "title": "The Hobbit",
    "author": "J.R.R. Tolkien",
    "categories": ["Fiction", "Fantasy
    "cover": "http://1.bp.blogspot.com/-tz40y0OlrCc/VGfG-NmL_AI/AAAAAAAAAJg/JVArqytkaOE/s1600/81Dd%2BimpKAL.jpg"
    "borrowingHistory": []

}

*/