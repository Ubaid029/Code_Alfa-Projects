const express = require('express')
const app = express()
const port = 5003
const path = require('path')
const exphbs = require('express-handlebars')
const cookieParser = require('cookie-parser')
const cors = require('cors')
const handlebars = require('handlebars')
const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access')
const bodyParser = require('body-parser')
const insecureHandlebars = allowInsecurePrototypeAccess(handlebars)
const jsonparser = bodyParser.json()
const urlencoded = bodyParser.urlencoded({extentded: false})
const bookRoutes = require('./routes/bookRoutes');
const Book = require('./model/Book')
// const dotenv = require('dotenv');



app.use(jsonparser)
app.use(urlencoded)
app.use('/api/books', bookRoutes);
app.use(cors());
app.use(express.json());

app.use(cookieParser())

app.engine('hbs', exphbs.engine({
    extname: 'hbs',
    defaultLayout: 'main',
    layoutsDir: path.join(__dirname, './views/layouts'),
    partialsDir: path.join(__dirname, './views/partials'),
    handlebars: allowInsecurePrototypeAccess(handlebars)
}));
app.set('view engine', 'hbs');
app.set('views', './views');

require("./database/dbConnect")

app.use(express.static("./public/"))
app.use(express.static("./uploads/"))

app.get('/api/books', function (req, res, next) {
    res.json({Book})
  })




// app.use("/api/usr/", require(path.join(__dirname, "./routes/usr/apiRoutes")))
// app.use("/api/order/", require(path.join(__dirname, "./routes/order/apiRoutes")))

// app.use("/prd/", require(path.join(__dirname, "./routes/productRoutes")))
// app.use("/user/", require(path.join(__dirname, "./routes/userRoutes")))

// app.listen(port, ()=>{
//     console.log("Server Started .... " + port)
// })


const PORT = process.env.PORT || 5003;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));




/* REAT + NODE
*
*
PRODUCT SAVE
USER REGISTER 
USER LOGIN (node = finduser route / return OK)
1>>>>>>>>>   if (OK) REACT HOME COMPONENT SHOW ELSE (404) ERROR COMPONENET
2>>>>>>>>>   if (OK) User Registered Email Address - Email Sent 
                (You are login at 07 Feb 2024 08:00)
* 
*/