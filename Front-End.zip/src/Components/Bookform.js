import React, { useState } from 'react';
import axios from 'axios';
import './Bookform.css';

const Bookform = () => {
  const [book, setBook] = useState({
    title: '',
    author: '',
    categories: '',
    isbn: '',
    borrowingHistory: [
      {
        borrowedDate: '',
        returnedDate: '',
      },
    ],
  });

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'borrowedDate' || name === 'returnedDate') {
      setBook((prevBook) => ({
        ...prevBook,
        borrowingHistory: [
          {
            ...prevBook.borrowingHistory[0],
            [name]: value,
          },
        ],
      }));
    } else {
      setBook((prevBook) => ({ ...prevBook, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');

    try {
      let res = await axios.post('http://localhost:5003/api/books', {
        ...book,
        categories: book.categories.split(',').map((cat) => cat.trim()),
      });
      alert('Book added successfully!');
      setBook({
        title: '',
        author: '',
        categories: '',
        isbn: '',
        borrowingHistory: [
          {
            borrowedDate: '',
            returnedDate: '',
          },
        ],
      });
    } catch (error) {
      console.error('Error adding book:', error);
      // Display specific error messages
      if (error.response) {
        // The request was made and the server responded with a status code
        setErrorMessage(`Error: ${error.response.status} - ${error.response.data}`);
      } else if (error.request) {
        // The request was made but no response was received
        setErrorMessage('No response received from server. Please check the server status.');
      } else {
        // Something happened in setting up the request that triggered an Error
        setErrorMessage('Error: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="formbody">
      <div className="container mt-4">
        <h1 className="display-4 text-center">
          <i className="fas fa-book-open text-primary"></i> Request
          <span className="title"> Book</span>
        </h1>
        {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
        <form id="book-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="title">Title</label>
            <input
              type="text"
              id="title"
              name="title"
              className="form-control"
              value={book.title}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="author">Author</label>
            <input
              type="text"
              id="author"
              name="author"
              className="form-control"
              value={book.author}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="categories">Categories (comma-separated)</label>
            <input
              type="text"
              id="categories"
              name="categories"
              className="form-control"
              value={book.categories}
              onChange={handleChange}
              required
            />
          </div>

          <input
            type="submit"
            value={loading ? 'Requesting...' : 'Request Book'}
            className="btn btn-primary btn-block"
            disabled={loading}
          />
        </form>
      </div>
    </div>
  );
};

export default Bookform;
